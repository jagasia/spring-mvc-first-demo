package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller			//everything you return by default is url
public class MyController {
	@RequestMapping("/")
	public String hello()
	{
		return "index";		//WEB-INF/jsp/index.jsp
	}
	
	@RequestMapping("/abt")
	public String aboutUs()
	{
		return "aboutus";	//WEB-INF/jsp/aboutus.jsp
	}
}
